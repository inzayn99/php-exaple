<?php
require_once "connection.php";
if (!empty($_GET['criteria'])) {
    $id = $_GET['criteria'];
    $query = "DELETE FROM students WHERE sid='$id'";
    $result = mysqli_query($connection, $query);
    if ($result == true) {
        $_SESSION['success'] = "Successfully deleted";
        redirect_to('index');

    } else {
        $_SESSION['error'] = "there was a problems";
        redirect_to('index');
    }

} else {
    $_SESSION['error'] = "invalid Access";
    redirect_to('index');
}