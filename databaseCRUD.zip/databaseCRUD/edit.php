<?php
require_once "connection.php";
if (!empty($_GET['criteria'])) {
    $id = $_GET['criteria'];
    $query = "SELECT * FROM students WHERE sid='$id'";
    $result = mysqli_query($connection, $query);
    $studentData = mysqli_fetch_assoc($result);
    $language = explode(',', $studentData['language']);

} else {
    $_SESSION['error'] = "invalid Access";
    redirect_to('index');
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-sm-12">
            <h1>Edit Record </h1>
            <hr>
            <form action="edit-action.php" method="post">
                <input type="hidden" name="criteria" value="<?= $studentData['sid'] ?>">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" name="name" value="<?= $studentData['name'] ?>" id="name" class="form-control">
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="text" name="email" value="<?= $studentData['email'] ?>" id="email"
                           class="form-control">
                </div>
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <label> <input type="radio" name="gender" <?= $studentData['gender'] == 'male' ? 'checked' : '' ?>
                                   value="male">Male</label>
                    <label> <input type="radio" <?= $studentData['gender'] == 'female' ? 'checked' : '' ?> name="gender"
                                   value="female">Female</label>

                </div>
                <div class="form-group">
                    <label for="lang">Language:</label>
                    <label> <input type="checkbox" name="lang[]" <?= in_array('nepali', $language) ? 'checked' : '' ?>
                                   value="nepali">Nepali</label>
                    <label> <input type="checkbox" name="lang[]" <?= in_array('english', $language) ? 'checked' : '' ?>
                                   value="english">English</label>
                    <label> <input type="checkbox" name="lang[]" <?= in_array('chinese', $language) ? 'checked' : '' ?>
                                   value="chinese">Chinese</label>

                </div>
                <div class="form-group">
                    <label for="country">Country:</label>
                    <select name="country" id="country" class="form-control">
                        <option <?= $studentData['country'] == 'nepal' ? 'selected' : '' ?> value="nepal">Nepal</option>
                        <option <?= $studentData['country'] == 'china' ? 'selected' : '' ?> value="china">China</option>
                        <option <?= $studentData['country'] == 'us' ? 'selected' : '' ?> value="us">US</option>
                    </select>
                </div>
                <div class="form-group">
                    <button class="btn btn-success">Edit Record</button>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
