<?php
require_once "connection.php";
if (!empty($_POST) && $_SERVER['REQUEST_METHOD'] === "POST") {
    $name = $_POST['name'];
    if (empty($_POST['name'])) {
        $_SESSION['error'] = 'name field is required';
        redirect_to("index");
        exit();
    }
    $email = $_POST['email'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
    $language = isset($_POST['lang']) ? implode(',', $_POST['lang']) : '';
    $country = isset($_POST['country']) ? $_POST['country'] : '';
    $id = $_POST['criteria'];
//======insert query=============
    $query = "UPDATE students SET name='$name',email='$email',
               gender='$gender',language='$language',country='$country'
               WHERE sid='$id'";
    $result = mysqli_query($connection, $query);
    if ($result == true) {
        $_SESSION['success'] = 'Successfully updated';
        redirect_to('index');
    } else {
        $_SESSION['error'] = 'There was a problems';
        redirect_to('index');
    }

} else {
    $_SESSION['error'] = 'Invalid Access';
    redirect_to('index');
}
