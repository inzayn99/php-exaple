<?php
require_once "connection.php";
if (!empty($_POST) && $_SERVER['REQUEST_METHOD'] === "POST") {
    $name = $_POST['name'];
    if (empty($_POST['name'])) {
        $_SESSION['error'] = 'name field is required';
        redirect_to("index");
        exit();
    }
    $email = $_POST['email'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
    $language = isset($_POST['lang']) ? implode(',', $_POST['lang']) : '';
    $country = isset($_POST['country']) ? $_POST['country'] : '';
//======insert query=============
    $query = "INSERT INTO students(name,email,gender,language,country)
    VALUES('$name','$email','$gender','$language','$country')";
    $result = mysqli_query($connection, $query);
    if ($result == true) {
        $_SESSION['success'] = 'Successfully inserted';
        redirect_to('index');
    } else {
        $_SESSION['error'] = 'There was a problems';
        redirect_to('index');
    }

} else {
    $_SESSION['error'] = 'Invalid Access';
    redirect_to('index');
}
