<?php
session_start();
/**
 * Database connection
 */
$connection = mysqli_connect('127.0.0.1','root', '', 'php11am');

if (!$connection) {
    die('mysqli not connected ' . mysqli_error($connection));
}

if (!function_exists('redirect_to')) {
    function redirect_to($path = null)
    {
        $path = str_replace('.php', '', $path);
        $path .= '.php';
        header('Location:' . $path);
        return true;
    }
}

