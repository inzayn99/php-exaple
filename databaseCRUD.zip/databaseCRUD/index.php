<?php
/*
 * link connection file here
 */
require_once "connection.php";

if (!empty($_GET['search'])) {
    $criteria = $_GET['search'];
    $query = "SELECT * FROM students WHERE 
                name LIKE '%$criteria%' ||
                email LIKE '%$criteria%' ||
                gender LIKE '%$criteria%' ||
                language LIKE '%$criteria%' ||
                country LIKE '%$criteria%'";
    $result = mysqli_query($connection, $query);
} else {
    $query = "SELECT * FROM students ORDER BY sid DESC";
    $result = mysqli_query($connection, $query);
}


?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PHP CRUD</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Add Record</h1>
            <hr>
            <!--  ==============success session messages=======-->
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php
                    echo $_SESSION['success'];
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>
            <!--  =========end success message======-->
            <!--  ==============error session messages=======-->
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>
            <!--  =========end errors message======-->
        </div>

        <div class="col-sm-4">
            <form action="insert.php" method="post">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" name="name" id="name" class="form-control">
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="text" name="email" id="email" class="form-control">
                </div>
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <label> <input type="radio" name="gender" value="male">Male</label>
                    <label> <input type="radio" name="gender" value="female">Female</label>

                </div>
                <div class="form-group">
                    <label for="lang">Language:</label>
                    <label> <input type="checkbox" name="lang[]" value="nepali">Nepali</label>
                    <label> <input type="checkbox" name="lang[]" value="english">English</label>
                    <label> <input type="checkbox" name="lang[]" value="chinese">Chinese</label>

                </div>
                <div class="form-group">
                    <label for="country">Country:</label>
                    <select name="country" id="country" class="form-control">
                        <option selected disabled>---Select Country---</option>
                        <option value="nepal">Nepal</option>
                        <option value="china">China</option>
                        <option value="us">US</option>
                    </select>
                </div>
                <div class="form-group">
                    <button class="btn btn-success">Add Record</button>
                </div>
            </form>
        </div>
        <div class="col-sm-6">
            <form action="">
                <div class="col-sm">
                    <div class="form-group">
                        <input type="text" name="search" class="form-control">
                    </div>
                </div>
                <div class="col-sm">
                    <div class="form-group">
                        <button>Search</button>
                    </div>
                </div>
            </form>

            <table class="table table-hover">
                <thead>
                <tr>
                    <th>S.n</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Language</th>
                    <th>Country</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($result as $key => $student) : ?>
                    <tr>
                        <td><?= ++$key; ?></td>
                        <td><?= $student['name'] ?></td>
                        <td><?= $student['email'] ?></td>
                        <td><?= $student['gender'] ?></td>
                        <td><?= $student['language'] ?></td>
                        <td><?= $student['country'] ?></td>
                        <td>
                            <a href="edit.php?criteria=<?= $student['sid'] ?>">E</a>
                            <a href="delete.php?criteria=<?= $student['sid'] ?>"
                               onclick="return confirm('are you sure?')">D</a>
                        </td>

                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>


    </div>
</div>
</body>
</html>